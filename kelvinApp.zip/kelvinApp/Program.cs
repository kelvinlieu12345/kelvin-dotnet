﻿using System;

namespace kelvinApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello");
            Console.WriteLine("Current time: " + DateTime.Now);
        }
    }
}
